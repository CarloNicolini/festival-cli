#include "board.h"

int sanity_checks(board b);
void close_holes_in_board(board b);

void turn_decorative_boxes_to_walls(board b);