#include "score.h"
#include "helper.h"
#include "tree.h"

void set_max_dist_data_in_node(tree* t, expansion_data* e, helper* h);
