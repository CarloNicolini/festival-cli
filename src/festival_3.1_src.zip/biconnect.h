#include "board.h"

int biconnect_score(board b, int report);

