#include "board.h"
#include "helper.h"

void save_full_parking_order(helper *h);
int overlap_score(board b, helper *h);
