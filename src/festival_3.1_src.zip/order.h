#include "board.h"

void set_order(board b, int pull_mode);
int score_using_order(board b);

