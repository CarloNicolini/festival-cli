// Festival Sokoban Solver
// Copyright 2018-2020 Yaron Shoham

#include "board.h"

int detect_corral(board b, board corral_options);


