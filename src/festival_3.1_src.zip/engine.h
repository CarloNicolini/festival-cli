// Festival Sokoban Solver
// Copyright 2018-2020 Yaron Shoham

#include "board.h"
#include "tree.h"

void FESS(board b, int time_allocation, int search_mode, tree *search_tree, helper *h);
