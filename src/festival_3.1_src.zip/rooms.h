// Festival Sokoban Solver
// Copyright 2018-2020 Yaron Shoham

#include "board.h"

int analyse_rooms(board b_inp);
int score_rooms(board b);

extern int_board rooms_board;
extern int rooms_num;
