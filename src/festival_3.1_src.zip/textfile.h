// Festival Sokoban Solver
// Copyright 2018-2020 Yaron Shoham

int textfile_fgets(char *s, int max_size);
void open_text_file(int pull_mode);
