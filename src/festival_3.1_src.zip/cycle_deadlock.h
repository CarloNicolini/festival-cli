#include "tree.h"
#include "helper.h"

void check_cycle_deadlock(tree* t, expansion_data* e, helper *h);