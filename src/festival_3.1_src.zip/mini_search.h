#include "board.h"
#include "moves.h"

int can_put_all_on_targets(board b, int max_size);
