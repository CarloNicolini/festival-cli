#include "board.h"

void mark_target_holes(board b);
void turn_target_holes_into_walls(board b);

extern board target_holes;
extern board semi_holes;
