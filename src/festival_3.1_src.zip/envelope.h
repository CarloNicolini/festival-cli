#include "board.h"

void init_envelope_patterns();
void fix_boxes_using_envelopes(board b);
