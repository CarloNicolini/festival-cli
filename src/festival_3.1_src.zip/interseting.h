#include "board.h"
#include "moves.h"

void mark_interesting_moves(board b, move *moves, int moves_num);